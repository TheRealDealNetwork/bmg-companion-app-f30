READ-ONLY export for Host Test 11-13 (Game 7).
Live slug: 2026-11-13-soebld-g7
Live game id: 27c6095ce968a015
The id 48a75f8976ecbdd0 is the GM seat (Host Test GM), not the game.

Source: published app read endpoints on bmg.soebluecollar.org. No INSERT/UPDATE/DELETE/ALTER. No publish. No game changed.
Raw SELECT against Neon was not possible from this workspace: the live DATABASE_URL is injected only on the published app and is not in the connected Neon or Vercel accounts.
Secret columns dropped: invite_token, seat keys, host keys, password hashes.
principle-bank.csv is the app source card bank (320 scenarios), not a database table. Cards and principles are not stored in metalcon.
