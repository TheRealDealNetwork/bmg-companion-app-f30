import { createHash, randomBytes } from "node:crypto";
import { normalizePhone } from "@/lib/game/format";
import type { DeptId } from "@/lib/game/types";
import { noteClosedAttempt, seatFor } from "./admin.server";
import { lookupMetalcon, scoreMetalcon } from "./cards";
import { payrollCentsFor, viewAnswer } from "./feedback";
import { METALCON_SEATS } from "./seats";
import { getMetalconSql } from "./db.server";

export const EVENT_ID = "metalcon-2026";
export const EVENT_LABEL = "SOE Business Learning Day";

const SEATS = new Set<string>(METALCON_SEATS);

function hash(secret: string) {
  return createHash("sha256").update(secret).digest("hex");
}

function cleanName(raw: string) {
  return raw.replace(/\s+/g, " ").trim().slice(0, 60);
}

function seatOf(value: string): DeptId | null {
  return SEATS.has(value) ? (value as DeptId) : null;
}

async function playerBySecret(id: string, secret: string) {
  if (!id || !secret) return null;
  const sql = await getMetalconSql();
  const rows = await sql<{ id: string; name: string; dept: string; game_id: string | null }>`
    select id, name, dept, game_id from metalcon.players
    where id = ${id} and secret_hash = ${hash(secret)} and event_id = ${EVENT_ID}
    limit 1
  `;
  const player = rows[0];
  if (!player?.game_id) return null;
  const games = await sql<{ status: string }>`
    select status from metalcon.games where id = ${player.game_id} limit 1
  `;
  if (games[0]?.status !== "live") return null;
  return player;
}

export async function registerSeat(input: {
  name: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  jobTitle?: string;
  phone: string;
  email: string;
  dept: string;
  terms: boolean;
  slug: string;
}) {
  if (!input.terms) return { ok: false as const, error: "Check Beta Terms & Conditions to take a seat." };
  const firstName = cleanName(input.firstName || "");
  const lastName = cleanName(input.lastName || "");
  const company = cleanName(input.company || "");
  const jobTitle = cleanName(input.jobTitle || "");
  const name = cleanName(`${firstName} ${lastName}`.trim() || input.name);
  if (firstName.length < 1) return { ok: false as const, error: "Enter a first name." };
  if (lastName.length < 1) return { ok: false as const, error: "Enter a last name." };
  if (company.length < 1) return { ok: false as const, error: "Enter a company name." };
  if (jobTitle.length < 1) return { ok: false as const, error: "Enter a title." };
  if (name.length < 2) return { ok: false as const, error: "Enter your name." };
  const phone = normalizePhone(input.phone);
  if (!phone) return { ok: false as const, error: "Enter a 10-digit mobile number." };
  const email = input.email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120) {
    return { ok: false as const, error: "Enter an email address." };
  }
  const dept = seatOf(input.dept);
  if (!dept) return { ok: false as const, error: "Choose a seat." };
  const seat = await seatFor(dept, input.slug);
  if (!seat.ok) return seat;
  const id = randomBytes(8).toString("hex");
  const secret = randomBytes(18).toString("hex");
  const sql = await getMetalconSql();
  await sql`
    insert into metalcon.players (id, event_id, game_id, secret_hash, invite_token, name, first_name, last_name, company, job_title, phone, email, dept, terms_at)
    values (${id}, ${EVENT_ID}, ${seat.gameId}, ${hash(secret)}, ${secret}, ${name}, ${firstName}, ${lastName}, ${company}, ${jobTitle}, ${phone}, ${email}, ${dept}, now())
  `;
  return { ok: true as const, player: { id, secret, name, dept } };
}

export async function findScenario(input: { id: string; secret: string; raw: string }) {
  const player = await playerBySecret(input.id, input.secret);
  if (!player) {
    await noteClosedAttempt(input.secret, `Card lookup ${input.raw}.`);
    return { ok: false as const, error: "Take a seat from the QR code first. If the host ended the game, this seat is closed." };
  }
  const found = lookupMetalcon(input.raw, player.dept as DeptId);
  if ("error" in found) return { ok: false as const, error: found.error };
  const sql = await getMetalconSql();
  const recent = await sql<{ n: number }>`
    select count(*)::int as n from metalcon.lookups
    where player_id = ${player.id} and created_at > now() - interval '10 minutes'
  `;
  if (Number(recent[0]?.n ?? 0) >= 15) {
    return { ok: false as const, error: "Too many cards in a short time. Play the one in front of you." };
  }
  await sql`
    insert into metalcon.lookups (id, game_id, player_id)
    values (${randomBytes(8).toString("hex")}, ${player.game_id}, ${player.id})
  `;
  return { ok: true as const, card: found.card, dept: player.dept };
}

async function roundRows(playerId: string, round: number) {
  const sql = await getMetalconSql();
  const rows = await sql<{ card_code: string; card_title: string; choice: string; payroll_cents: number }>`
    select card_code, card_title, choice, payroll_cents
    from metalcon.answers
    where event_id = ${EVENT_ID} and player_id = ${playerId} and round_n = ${round}
    order by created_at
  `;
  return rows.map((row) => {
    const view = viewAnswer(row.card_code, row.choice);
    return {
      ...row,
      score_label: view?.scoreLabel ?? "",
      payroll_label: view?.payrollLabel ?? "",
      off_dollars: view?.offDollars ?? 0,
      added_points: view?.addedPoints ?? 0,
      points: view?.points ?? null,
    };
  });
}

export async function roundSheet(input: { id: string; secret: string; round: number }) {
  const player = await playerBySecret(input.id, input.secret);
  if (!player) return { ok: false as const, error: "Take a seat from the QR code first.", rows: [] };
  const round = Math.round(input.round);
  if (!Number.isFinite(round) || round < 1) return { ok: true as const, rows: [] };
  return { ok: true as const, rows: await roundRows(player.id, round) };
}

export async function lockScenario(input: {
  id: string;
  secret: string;
  code: string;
  choice: string;
  round: number;
}) {
  const player = await playerBySecret(input.id, input.secret);
  if (!player) {
    await noteClosedAttempt(input.secret, `Tried to lock ${input.code}.`);
    return { ok: false as const, error: "Take a seat from the QR code first. If the host ended the game, this seat is closed." };
  }
  const choice = input.choice === "A" || input.choice === "B" || input.choice === "C" ? input.choice : null;
  if (!choice) return { ok: false as const, error: "Choose A, B, or C." };
  const round = Math.round(input.round);
  if (!Number.isFinite(round) || round < 1 || round > 200) return { ok: false as const, error: "Enter the round number." };
  const card = scoreMetalcon(input.code.trim().toUpperCase());
  if (!card || card.dept !== player.dept) return { ok: false as const, error: "That card is not in this seat's deck." };
  const sql = await getMetalconSql();
  const existing = await sql<{ choice: string; payroll_cents: number; choice_text: string }>`
    select choice, payroll_cents, choice_text from metalcon.answers
    where event_id = ${EVENT_ID} and player_id = ${player.id} and round_n = ${round} and card_code = ${card.code}
    limit 1
  `;
  if (existing[0]) {
    const savedChoice = existing[0].choice === "A" || existing[0].choice === "B" || existing[0].choice === "C" ? existing[0].choice : choice;
    return {
      ok: true as const,
      duplicate: true,
      payrollCents: existing[0].payroll_cents,
      choice: savedChoice,
      choiceText: existing[0].choice_text,
      feedback: viewAnswer(card.code, savedChoice),
      rows: await roundRows(player.id, round),
    };
  }
  const payrollCents = payrollCentsFor(card.code, choice);
  const id = randomBytes(8).toString("hex");
  await sql`
    insert into metalcon.answers (
      id, event_id, game_id, player_id, round_n, dept, player_name, card_code, card_title, choice, choice_text, payroll_cents
    ) values (
      ${id}, ${EVENT_ID}, ${player.game_id}, ${player.id}, ${round}, ${player.dept}, ${player.name},
      ${card.code}, ${card.title}, ${choice}, ${card.options[choice]}, ${payrollCents}
    )
  `;
  return {
    ok: true as const,
    duplicate: false,
    payrollCents,
    choice,
    choiceText: card.options[choice],
    feedback: viewAnswer(card.code, choice),
    rows: await roundRows(player.id, round),
  };
}

export async function answerLog() {
  const sql = await getMetalconSql();
  const games = await sql<{ id: string; n: number }>`
    select id, n from metalcon.games where status = 'live' order by n desc limit 1
  `;
  const game = games[0] ?? (await sql<{ id: string; n: number }>`select id, n from metalcon.games order by n desc limit 1`)[0];
  if (!game) return { ok: true as const, label: EVENT_LABEL, game: null, rows: [] };
  const rows = await sql<{
    round_n: number;
    dept: string;
    player_name: string;
    card_code: string;
    card_title: string;
    choice: string;
    payroll_cents: number;
  }>`
    select round_n, dept, player_name, card_code, card_title, choice, payroll_cents
    from metalcon.answers
    where event_id = ${EVENT_ID} and game_id = ${game.id}
    order by round_n, dept, created_at
  `;
  return {
    ok: true as const,
    label: EVENT_LABEL,
    game: game.n,
    rows: rows.map((row) => {
      const view = viewAnswer(row.card_code, row.choice);
      return {
        ...row,
        score_label: view?.scoreLabel ?? "",
        payroll_label: view?.payrollLabel ?? "",
      };
    }),
  };
}

const voiceCache = new Map<string, string>();

export async function speakMale(text: string) {
  const spoken = text.replace(/\s+/g, " ").trim().slice(0, 1800);
  if (spoken.length < 2) return { ok: false as const, error: "Nothing to read." };
  const hit = voiceCache.get(spoken);
  if (hit) return { ok: true as const, audio: hit };
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false as const, error: "Read aloud is not available right now." };
  const res = await fetch("https://api.x.ai/v1/tts", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ text: spoken, voice_id: "rex", language: "en" }),
  });
  if (!res.ok) return { ok: false as const, error: "Read aloud is not available right now." };
  const bytes = Buffer.from(await res.arrayBuffer());
  if (bytes.length < 80) return { ok: false as const, error: "Read aloud is not available right now." };
  const audio = bytes.toString("base64");
  if (voiceCache.size > 40) voiceCache.clear();
  voiceCache.set(spoken, audio);
  return { ok: true as const, audio };
}
