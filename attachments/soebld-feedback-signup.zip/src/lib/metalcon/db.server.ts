import { randomBytes } from "node:crypto";
import type { Sql } from "@/lib/db";

const OID_INT8 = 20;
const OID_DATE = 1082;
const OID_INTERVAL = 1186;
const identity = (value: string) => value;

type Run = <T>(text: string, params: unknown[]) => Promise<T[]>;

function toSql(run: Run): Sql {
  const sql = (async <T = Record<string, unknown>>(
    strings: TemplateStringsArray,
    ...values: unknown[]
  ): Promise<T[]> => {
    let text = strings[0] ?? "";
    for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1] ?? ""}`;
    return run<T>(text, values);
  }) as Sql;
  sql.query = <T = Record<string, unknown>>(text: string, params: unknown[] = []) => run<T>(text, params);
  return sql;
}

const globalRef = globalThis as typeof globalThis & {
  __metalconSqlV5__?: Promise<Sql>;
};

const SCHEMA = `
create schema if not exists metalcon;
create table if not exists metalcon.event (
  id text primary key,
  label text not null,
  created_at timestamptz not null default now()
);
insert into metalcon.event (id, label)
values ('metalcon-2026', 'SOE Business Learning Day')
on conflict (id) do update set label = excluded.label;
create table if not exists metalcon.games (
  id text primary key,
  n integer not null,
  status text not null default 'live',
  share_seat boolean not null default true,
  created_at timestamptz not null default now(),
  ended_at timestamptz
);
alter table metalcon.games add column if not exists registration_open boolean not null default true;
alter table metalcon.games add column if not exists slug text;
alter table metalcon.games add column if not exists event_name text;
alter table metalcon.games add column if not exists host_id text;
create unique index if not exists metalcon_games_slug on metalcon.games (slug);
create table if not exists metalcon.hosts (
  id text primary key,
  name text not null,
  email text not null unique,
  password_hash text not null,
  role text not null,
  created_at timestamptz not null default now()
);
create table if not exists metalcon.revoked (
  id text primary key,
  game_id text not null,
  secret_hash text not null,
  player_name text not null,
  dept text not null,
  created_at timestamptz not null default now()
);
create table if not exists metalcon.alerts (
  id text primary key,
  game_id text,
  kind text not null,
  detail text not null,
  created_at timestamptz not null default now()
);
create table if not exists metalcon.archives (
  id text primary key,
  game_id text not null,
  n integer not null,
  csv text not null,
  created_at timestamptz not null default now()
);
create table if not exists metalcon.lookups (
  id text primary key,
  game_id text not null,
  player_id text not null,
  created_at timestamptz not null default now()
);
create table if not exists metalcon.players (
  id text primary key,
  event_id text not null default 'metalcon-2026',
  game_id text,
  secret_hash text not null,
  invite_token text,
  name text not null,
  phone text not null,
  email text not null,
  dept text not null,
  terms_at timestamptz,
  created_at timestamptz not null default now()
);
alter table metalcon.players add column if not exists game_id text;
alter table metalcon.players add column if not exists invite_token text;
alter table metalcon.players alter column terms_at drop not null;
alter table metalcon.players add column if not exists first_name text not null default '';
alter table metalcon.players add column if not exists last_name text not null default '';
alter table metalcon.players add column if not exists company text not null default '';
alter table metalcon.players add column if not exists job_title text not null default '';
create table if not exists metalcon.answers (
  id text primary key,
  event_id text not null default 'metalcon-2026',
  game_id text,
  player_id text not null,
  round_n integer not null,
  dept text not null,
  player_name text not null,
  card_code text not null,
  card_title text not null,
  choice text not null,
  choice_text text not null,
  payroll_cents integer not null,
  created_at timestamptz not null default now()
);
alter table metalcon.answers add column if not exists game_id text;
create table if not exists metalcon.host_leads (
  id text primary key,
  company text not null,
  contact_name text not null,
  title text not null default '',
  phone text not null default '',
  email text not null default '',
  city text not null default '',
  state text not null default '',
  headcount text not null default '',
  timing text not null default '',
  notes text not null default '',
  ghl_contact_id text,
  created_at timestamptz not null default now()
);
`;

async function applySchema(exec: (text: string) => Promise<void>) {
  for (const statement of SCHEMA.split(";").map((part) => part.trim()).filter(Boolean)) {
    await exec(statement);
  }
}

async function backfill(query: (text: string, params?: unknown[]) => Promise<Record<string, unknown>[]>) {
  const games = await query("select id from metalcon.games order by n desc limit 1");
  const orphan = await query("select count(*)::int as n from metalcon.players where game_id is null");
  const count = Number(orphan[0]?.n ?? 0);
  if (!count) return;
  let gameId = games[0]?.id ? String(games[0].id) : "";
  if (!gameId) {
    gameId = randomBytes(8).toString("hex");
    await query("insert into metalcon.games (id, n, status, share_seat) values ($1, 1, 'live', true)", [gameId]);
  }
  await query("update metalcon.players set game_id = $1 where game_id is null", [gameId]);
  await query("update metalcon.answers set game_id = $1 where game_id is null", [gameId]);
}

async function openPglite(): Promise<Sql> {
  const { PGlite } = await import("@electric-sql/pglite");
  const { mkdirSync } = await import("node:fs");
  const parsers = { [OID_INT8]: Number, [OID_DATE]: identity, [OID_INTERVAL]: identity };
  const dir = "/workspace/.data/metalcon-2026";
  mkdirSync(dir, { recursive: true });
  const pg = new PGlite(dir, { parsers });
  await pg.waitReady;
  await applySchema((text) => pg.exec(text).then(() => undefined));
  await backfill(async (text, params = []) => {
    const result = await pg.query<Record<string, unknown>>(text, params);
    return result.rows;
  });
  return toSql(async <T>(text: string, params: unknown[]) => {
    const result = await pg.query<T>(text, params);
    return result.rows;
  });
}

async function openNeon(gameUrl: string): Promise<Sql> {
  const { Pool, types } = await import("pg");
  types.setTypeParser(OID_INT8, Number);
  types.setTypeParser(OID_DATE, identity);
  types.setTypeParser(OID_INTERVAL, identity);
  const pool = new Pool({
    connectionString: gameUrl,
    connectionTimeoutMillis: 8000,
    max: 2,
  });
  await applySchema(async (text) => {
    await pool.query(text);
  });
  await backfill(async (text, params = []) => {
    const result = await pool.query(text, params);
    return result.rows as Record<string, unknown>[];
  });
  return toSql(async <T>(text: string, params: unknown[]) => {
    const result = await pool.query(text, params);
    return result.rows as T[];
  });
}

async function openExisting(connectionString: string): Promise<Sql> {
  const { Pool, types } = await import("pg");
  types.setTypeParser(OID_INT8, Number);
  types.setTypeParser(OID_DATE, identity);
  types.setTypeParser(OID_INTERVAL, identity);
  const pool = new Pool({ connectionString });
  await applySchema(async (text) => {
    await pool.query(text);
  });
  await backfill(async (text, params = []) => {
    const result = await pool.query(text, params);
    return result.rows as Record<string, unknown>[];
  });
  return toSql(async <T>(text: string, params: unknown[]) => {
    const result = await pool.query(text, params);
    return result.rows as T[];
  });
}

/** METALCON 2026 tables only, in the metalcon schema. Game tables are never read or written. */
export function getMetalconSql(): Promise<Sql> {
  globalRef.__metalconSqlV5__ ??= (async () => {
    const dedicated = process.env.METALCON_DATABASE_URL?.trim();
    if (dedicated) return openExisting(dedicated);
    const gameUrl = process.env.DATABASE_URL?.trim();
    if (!gameUrl) return openPglite();
    return openNeon(gameUrl);
  })().catch((err) => {
    globalRef.__metalconSqlV5__ = undefined;
    throw err;
  });
  return globalRef.__metalconSqlV5__;
}
