import { createServerFn } from "@tanstack/react-start";

export const registerSeat = createServerFn({ method: "POST" })
  .validator((input: {
    name?: string;
    firstName?: string;
    lastName?: string;
    company?: string;
    jobTitle?: string;
    phone?: string;
    email?: string;
    dept?: string;
    terms?: boolean;
    slug?: string;
  }) => ({
    name: String(input?.name ?? ""),
    firstName: String(input?.firstName ?? ""),
    lastName: String(input?.lastName ?? ""),
    company: String(input?.company ?? ""),
    jobTitle: String(input?.jobTitle ?? ""),
    phone: String(input?.phone ?? ""),
    email: String(input?.email ?? ""),
    dept: String(input?.dept ?? ""),
    terms: Boolean(input?.terms),
    slug: String(input?.slug ?? ""),
  }))
  .handler(async ({ data }) => {
    try {
      const { registerSeat: run } = await import("./server");
      return await run(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not save the seat.";
      return { ok: false as const, error: message };
    }
  });

export const findScenario = createServerFn({ method: "POST" })
  .validator((input: { id?: string; secret?: string; raw?: string }) => ({
    id: String(input?.id ?? ""),
    secret: String(input?.secret ?? ""),
    raw: String(input?.raw ?? ""),
  }))
  .handler(async ({ data }) => {
    try {
      const { findScenario: run } = await import("./server");
      return await run(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not find that card.";
      return { ok: false as const, error: message };
    }
  });

export const lockScenario = createServerFn({ method: "POST" })
  .validator((input: { id?: string; secret?: string; code?: string; choice?: string; round?: number }) => ({
    id: String(input?.id ?? ""),
    secret: String(input?.secret ?? ""),
    code: String(input?.code ?? ""),
    choice: String(input?.choice ?? ""),
    round: Number(input?.round ?? 0),
  }))
  .handler(async ({ data }) => {
    try {
      const { lockScenario: run } = await import("./server");
      return await run(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not save that answer.";
      return { ok: false as const, error: message };
    }
  });

export const roundSheet = createServerFn({ method: "POST" })
  .validator((input: { id?: string; secret?: string; round?: number }) => ({
    id: String(input?.id ?? ""),
    secret: String(input?.secret ?? ""),
    round: Number(input?.round ?? 0),
  }))
  .handler(async ({ data }) => {
    try {
      const { roundSheet: run } = await import("./server");
      return await run(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not load this round.";
      return { ok: false as const, error: message, rows: [] };
    }
  });

export const adminEnter = createServerFn({ method: "POST" })
  .validator((input: { password?: string; email?: string }) => ({
    password: String(input?.password ?? ""),
    email: String(input?.email ?? ""),
  }))
  .handler(async ({ data }) => {
    const { adminEnter: run } = await import("./admin.server");
    return run(data.password, data.email);
  });

export const adminDesk = createServerFn({ method: "POST" })
  .validator((input: { token?: string }) => ({ token: String(input?.token ?? "") }))
  .handler(async ({ data }) => {
    const { adminDesk: run } = await import("./admin.server");
    return run(data.token);
  });

export const createHost = createServerFn({ method: "POST" })
  .validator((input: { token?: string; name?: string; email?: string; password?: string }) => ({
    token: String(input?.token ?? ""),
    name: String(input?.name ?? ""),
    email: String(input?.email ?? ""),
    password: String(input?.password ?? ""),
  }))
  .handler(async ({ data }) => {
    const { createHost: run } = await import("./admin.server");
    return run(data);
  });

export const startGame = createServerFn({ method: "POST" })
  .validator((input: { token?: string; eventName?: string }) => ({
    token: String(input?.token ?? ""),
    eventName: String(input?.eventName ?? ""),
  }))
  .handler(async ({ data }) => {
    const { startGame: run } = await import("./admin.server");
    return run(data.token, data.eventName);
  });

export const endGame = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
  }))
  .handler(async ({ data }) => {
    const { endGame: run } = await import("./admin.server");
    return run(data.token, data.gameId);
  });

export const reopenGame = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
  }))
  .handler(async ({ data }) => {
    const { reopenGame: run } = await import("./admin.server");
    return run(data.token, data.gameId);
  });

export const resetGame = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
  }))
  .handler(async ({ data }) => {
    const { resetGame: run } = await import("./admin.server");
    return run(data.token, data.gameId);
  });

export const setSignup = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string; open?: boolean }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
    open: Boolean(input?.open),
  }))
  .handler(async ({ data }) => {
    const { setSignup: run } = await import("./admin.server");
    return run(data.token, data.gameId, data.open);
  });

export const setShareSeat = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string; share?: boolean }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
    share: Boolean(input?.share),
  }))
  .handler(async ({ data }) => {
    const { setShareSeat: run } = await import("./admin.server");
    return run(data.token, data.gameId, data.share);
  });

export const placePlayer = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string; name?: string; phone?: string; email?: string; dept?: string }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
    name: String(input?.name ?? ""),
    phone: String(input?.phone ?? ""),
    email: String(input?.email ?? ""),
    dept: String(input?.dept ?? ""),
  }))
  .handler(async ({ data }) => {
    const { placePlayer: run } = await import("./admin.server");
    return run(data);
  });

export const sendSeatLink = createServerFn({ method: "POST" })
  .validator((input: { token?: string; playerId?: string; origin?: string }) => ({
    token: String(input?.token ?? ""),
    playerId: String(input?.playerId ?? ""),
    origin: String(input?.origin ?? ""),
  }))
  .handler(async ({ data }) => {
    const { sendSeatLink: run } = await import("./admin.server");
    return run(data);
  });

export const exportGame = createServerFn({ method: "POST" })
  .validator((input: { token?: string; gameId?: string }) => ({
    token: String(input?.token ?? ""),
    gameId: String(input?.gameId ?? ""),
  }))
  .handler(async ({ data }) => {
    const { exportGame: run } = await import("./admin.server");
    return run(data.token, data.gameId);
  });

export const claimSeat = createServerFn({ method: "POST" })
  .validator((input: { id?: string; token?: string; terms?: boolean }) => ({
    id: String(input?.id ?? ""),
    token: String(input?.token ?? ""),
    terms: Boolean(input?.terms),
  }))
  .handler(async ({ data }) => {
    const { claimSeat: run } = await import("./admin.server");
    return run(data);
  });

export const answerLog = createServerFn({ method: "GET" }).handler(async () => {
  const { answerLog: run } = await import("./server");
  return run();
});

export const speakMale = createServerFn({ method: "POST" })
  .validator((input: { text?: string }) => ({ text: String(input?.text ?? "").slice(0, 1800) }))
  .handler(async ({ data }) => {
    const { speakMale: run } = await import("./server");
    return run(data.text);
  });

export const submitHostLead = createServerFn({ method: "POST" })
  .validator((input: {
    company?: string;
    name?: string;
    title?: string;
    phone?: string;
    email?: string;
    city?: string;
    state?: string;
    headcount?: string;
    timing?: string;
    notes?: string;
    contact?: boolean;
  }) => ({
    company: String(input?.company ?? ""),
    name: String(input?.name ?? ""),
    title: String(input?.title ?? ""),
    phone: String(input?.phone ?? ""),
    email: String(input?.email ?? ""),
    city: String(input?.city ?? ""),
    state: String(input?.state ?? ""),
    headcount: String(input?.headcount ?? ""),
    timing: String(input?.timing ?? ""),
    notes: String(input?.notes ?? ""),
    contact: Boolean(input?.contact),
  }))
  .handler(async ({ data }) => {
    try {
      const { submitHostLead: run } = await import("./admin.server");
      return await run(data);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not save that. Try again.";
      return { ok: false as const, error: message };
    }
  });

export const exportHostLeads = createServerFn({ method: "POST" })
  .validator((input: { token?: string }) => ({ token: String(input?.token ?? "") }))
  .handler(async ({ data }) => {
    const { exportHostLeads: run } = await import("./admin.server");
    return run(data.token);
  });
